# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: resize-scheduling.spec.ts >> showcase-control / sequence 5
- Location: e2e/resize-scheduling.spec.ts:19:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('navigation', { name: 'Main', exact: true }).locator('[data-nav-index="more"] > button')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByRole('navigation', { name: 'Main', exact: true }).locator('[data-nav-index="more"] > button')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to content" [ref=e2]:
    - /url: "#content"
  - banner [ref=e3]:
    - generic [ref=e4]:
      - paragraph [ref=e5]:
        - text: Lumen 3 Pro is here —
        - link "see what changed" [ref=e6]:
          - /url: /lumen-3-pro
      - button "Dismiss announcement" [ref=e7] [cursor=pointer]
    - generic [ref=e10]:
      - generic [ref=e11]:
        - link "Lumen" [ref=e13]:
          - /url: /
          - img "Lumen" [ref=e14]
        - navigation "Main" [ref=e15]:
          - list [ref=e16]:
            - listitem [ref=e17]:
              - button "More" [active] [ref=e18] [cursor=pointer]
      - generic [ref=e21]:
        - button "Search" [ref=e22] [cursor=pointer]:
          - generic [ref=e27]: ⌘K
        - button "Change theme" [ref=e29] [cursor=pointer]
        - button "Switch to dark theme" [ref=e36] [cursor=pointer]
        - link "GitHub repository" [ref=e40] [cursor=pointer]:
          - /url: https://github.com/shebka/zellij
        - link "Buy" [ref=e43] [cursor=pointer]:
          - /url: /lumen-3-pro#buy
  - main [ref=e44]:
    - heading "Lumen" [level=1] [ref=e45]
    - generic [ref=e48]:
      - generic [ref=e52]:
        - paragraph [ref=e53]: Lumen 3 Pro
        - paragraph [ref=e54]: Titanium. Featherweight. Relentless.
        - paragraph [ref=e55]: The brightest display we have built, and a battery that outlasts the day you actually had.
        - paragraph [ref=e56]:
          - link "Learn more" [ref=e57]:
            - /url: /lumen-3-pro
            - text: Learn more ›
          - link "Buy" [ref=e58]:
            - /url: /lumen-3-pro#buy
            - text: Buy ›
      - generic [ref=e62]:
        - paragraph [ref=e63]: Lumen 3
        - paragraph [ref=e64]: Everything you need. Nothing you don't.
        - paragraph [ref=e65]:
          - link "Learn more" [ref=e66]:
            - /url: /lumen-3-pro
            - text: Learn more ›
          - link "Buy" [ref=e67]:
            - /url: /lumen-3-pro#buy
            - text: Buy ›
      - generic [ref=e71]:
        - paragraph [ref=e72]: Lumen Watch
        - paragraph [ref=e73]: A day, measured properly.
        - paragraph [ref=e74]:
          - link "Learn more" [ref=e75]:
            - /url: /lumen-3-pro
            - text: Learn more ›
      - generic [ref=e79]:
        - paragraph [ref=e80]: Lumen Buds
        - paragraph [ref=e81]: Quiet, on demand.
        - paragraph [ref=e82]:
          - link "Learn more" [ref=e83]:
            - /url: /lumen-3-pro
            - text: Learn more ›
      - link "Trade in Get up to £600 toward a new Lumen." [ref=e85]:
        - /url: /lumen-3-pro#trade
        - generic [ref=e87]:
          - paragraph [ref=e88]: Trade in
          - paragraph [ref=e89]: Get up to £600 toward a new Lumen.
    - generic [ref=e90]:
      - generic [ref=e92]:
        - heading "Why buy from Lumen" [level=2] [ref=e94]
        - link "Shop all" [ref=e95]:
          - /url: /lumen-3-pro
          - text: Shop all ›
      - generic [ref=e96]:
        - group "Why buy from Lumen" [ref=e97]:
          - article [ref=e98]:
            - link "Trade in Turn the one in your pocket into credit. An estimate takes two minutes, and the value comes off at checkout." [ref=e99]:
              - /url: /lumen-3-pro#trade
              - generic [ref=e100]:
                - paragraph [ref=e101]: Trade in
                - paragraph [ref=e102]: Turn the one in your pocket into credit.
                - paragraph [ref=e103]: An estimate takes two minutes, and the value comes off at checkout.
          - article [ref=e106]:
            - link "Carriers Every network, no upsell. Bring the number you have, on the plan you already pay for." [ref=e107]:
              - /url: /lumen-3-pro#buy
              - generic [ref=e108]:
                - paragraph [ref=e109]: Carriers
                - paragraph [ref=e110]: Every network, no upsell.
                - paragraph [ref=e111]: Bring the number you have, on the plan you already pay for.
          - article [ref=e114]:
            - link "Pay monthly Spread it over 24 months, interest free. No deposit, no fee, and settle early whenever you like." [ref=e115]:
              - /url: /lumen-3-pro#buy
              - generic [ref=e116]:
                - paragraph [ref=e117]: Pay monthly
                - paragraph [ref=e118]: Spread it over 24 months, interest free.
                - paragraph [ref=e119]: No deposit, no fee, and settle early whenever you like.
          - article [ref=e122]:
            - link "Setup Everything moves across in one go. Photos, messages, apps, and the way you had them arranged." [ref=e123]:
              - /url: /guide/quickstart
              - generic [ref=e124]:
                - paragraph [ref=e125]: Setup
                - paragraph [ref=e126]: Everything moves across in one go.
                - paragraph [ref=e127]: Photos, messages, apps, and the way you had them arranged.
          - article [ref=e130]:
            - link "Support A person, not a phone tree. Free for two years, by chat or in person, whichever suits." [ref=e131]:
              - /url: /guide
              - generic [ref=e132]:
                - paragraph [ref=e133]: Support
                - paragraph [ref=e134]: A person, not a phone tree.
                - paragraph [ref=e135]: Free for two years, by chat or in person, whichever suits.
        - generic [ref=e138]:
          - button "Scroll left" [disabled] [ref=e139]
          - button "Scroll right" [ref=e142] [cursor=pointer]
  - contentinfo [ref=e145]:
    - generic [ref=e146]:
      - generic [ref=e147]:
        - text: Lumen
        - paragraph [ref=e148]: Light, captured.
      - navigation "Footer" [ref=e149]:
        - generic [ref=e150]:
          - heading "Shop" [level=2] [ref=e151]
          - list [ref=e152]:
            - listitem [ref=e153]:
              - link "Lumen 3 Pro" [ref=e154]:
                - /url: /lumen-3-pro
            - listitem [ref=e155]:
              - link "Trade in" [ref=e156]:
                - /url: /lumen-3-pro#trade
        - generic [ref=e157]:
          - heading "Learn" [level=2] [ref=e158]
          - list [ref=e159]:
            - listitem [ref=e160]:
              - link "Guide" [ref=e161]:
                - /url: /guide
            - listitem [ref=e162]:
              - link "Specifications" [ref=e163]:
                - /url: /lumen-3-pro#specs
        - generic [ref=e164]:
          - heading "Support" [level=2] [ref=e165]
          - list [ref=e166]:
            - listitem [ref=e167]:
              - link "Getting started" [ref=e168]:
                - /url: /guide/quickstart
    - generic [ref=e169]:
      - paragraph [ref=e170]: © 2026 Lumen — a fictional brand, built to exercise Zellij.
      - list [ref=e171]:
        - listitem [ref=e172]:
          - link "Github" [ref=e173]:
            - /url: https://github.com/shebka/zellij
  - alert [ref=e174]
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { writeFile } from 'node:fs/promises';
  3  | import { browserFailureState } from '../../../scripts/browser-failure-state.mjs';
  4  | const variants = [{ name: 'showcase-control', url: '/' }];
  5  | const observedErrors = new WeakMap<Page, string[]>();
  6  | test.afterEach(async ({ page }, info) => {
  7  |   if (info.status === info.expectedStatus) return;
  8  |   const output = info.outputPath('resize-state.json');
  9  |   await writeFile(output, JSON.stringify({ status: info.status, title: info.title,
  10 |     worker: info.parallelIndex, pageErrors: observedErrors.get(page) ?? [],
  11 |     state: await browserFailureState(page) }, null, 2));
  12 |   await info.attach('resize-state', { path: output, contentType: 'application/json' });
  13 | });
  14 | 
  15 | // Distinct cases share the normal two worker/browser processes. No repeat-each
  16 | // worker restart, active heartbeat or injected stall; assertion deadlines stay 5s.
  17 | for (let iteration = 0; iteration < 32; iteration++) {
  18 |   for (const variant of variants) {
  19 |     test(`${variant.name} / sequence ${iteration + 1}`, async ({ page }, info) => {
  20 |       const errors: string[] = [];
  21 |       observedErrors.set(page, errors);
  22 |       page.on('pageerror', error => errors.push(error.message));
  23 |       await page.goto(variant.url, { waitUntil: 'networkidle' });
  24 |       await page.evaluate(() => document.fonts.ready);
  25 |       const nav = page.getByRole('navigation', { name: 'Main', exact: true });
  26 |       if (variant.url === '/') {
  27 |         await page.addStyleTag({ content: '.zellij-nav-link, .zellij-nav-probe-label { font-size: 1.25rem; }' });
  28 |       }
  29 |       for (let cycle = 0; cycle < 5; cycle++) {
  30 |         await test.step(`narrow/open/Escape/widen ${cycle + 1}`, async () => {
  31 |           await page.setViewportSize({ width: 901, height: 900 });
  32 |           const more = nav.locator('[data-nav-index="more"] > button');
  33 |           await expect(more).toBeVisible();
  34 |           await expect(nav.locator('[data-nav-index]:not([data-nav-index="more"])')).toHaveCount(0);
  35 |           await more.focus();
  36 |           await page.keyboard.press('ArrowDown');
  37 |           await expect(nav.locator('[data-nav-index="more"] a').first()).toBeFocused();
  38 |           await expect(nav.locator('[data-nav-index="more"] a').filter({ hasText: 'Guide' }).last()).toBeVisible();
  39 |           await page.keyboard.press('Escape');
  40 |           await expect(more).toBeFocused();
  41 |           // Keep the critical Escape → resize interval free of extra evaluation.
  42 |           await page.setViewportSize({ width: 1600, height: 900 });
> 43 |           await expect(more).toHaveCount(0);
     |                              ^ Error: expect(locator).toHaveCount(expected) failed
  44 |           await expect(nav.getByRole('link', { name: 'Guide', exact: true })).toBeVisible();
  45 |           await expect(nav.locator('[data-zellij-navitem]:focus')).toHaveCount(1);
  46 |         });
  47 |       }
  48 |       await info.attach('page-errors', { body: JSON.stringify(errors), contentType: 'application/json' });
  49 |       expect(errors).toEqual([]);
  50 |     });
  51 |   }
  52 | }
  53 | 
```