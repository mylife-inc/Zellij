# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: resize-scheduling.spec.ts >> showcase-control / sequence 27
- Location: e2e/resize-scheduling.spec.ts:25:5

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('navigation', { name: 'Main', exact: true }).locator('[data-nav-index="more"] > button')
Expected: 0
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" with timeout 5000ms
  - waiting for getByRole('navigation', { name: 'Main', exact: true }).locator('[data-nav-index="more"] > button')
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2]:
    - /url: "#content"
  - banner [ref=e3]:
    - generic [ref=e4]:
      - paragraph [ref=e5]:
        - text: Lumen 3 Pro is here —
        - link "see what changed" [ref=e6]:
          - /url: /lumen-3-pro
      - button "Dismiss announcement" [ref=e7] [cursor=pointer]
    - generic [ref=e10]:
      - generic [ref=e11]:
        - link "Lumen" [ref=e13]:
          - /url: /
          - img "Lumen" [ref=e14]
        - navigation "Main" [ref=e15]:
          - list [ref=e16]:
            - listitem [ref=e17]:
              - link "Lumen 3 Pro" [ref=e18] [cursor=pointer]:
                - /url: /lumen-3-pro
            - listitem [ref=e19]:
              - button "Shop" [ref=e20] [cursor=pointer]
            - listitem [ref=e23]:
              - button "Explore" [ref=e24] [cursor=pointer]
            - listitem [ref=e27]:
              - link "Specs" [ref=e28] [cursor=pointer]:
                - /url: /lumen-3-pro#specs
            - listitem [ref=e29]:
              - link "Guide" [ref=e30] [cursor=pointer]:
                - /url: /guide
      - generic [ref=e31]:
        - button "Search" [ref=e32] [cursor=pointer]:
          - generic [ref=e37]: ⌘K
        - button "Change theme" [ref=e39] [cursor=pointer]
        - button "Switch to dark theme" [ref=e46] [cursor=pointer]
        - link "GitHub repository" [ref=e50] [cursor=pointer]:
          - /url: https://github.com/shebka/zellij
        - link "Buy" [ref=e53] [cursor=pointer]:
          - /url: /lumen-3-pro#buy
  - main [ref=e54]:
    - heading "Lumen" [level=1] [ref=e55]
    - generic [ref=e58]:
      - generic [ref=e62]:
        - paragraph [ref=e63]: Lumen 3 Pro
        - paragraph [ref=e64]: Titanium. Featherweight. Relentless.
        - paragraph [ref=e65]: The brightest display we have built, and a battery that outlasts the day you actually had.
        - paragraph [ref=e66]:
          - link "Learn more" [ref=e67]:
            - /url: /lumen-3-pro
            - text: Learn more ›
          - link "Buy" [ref=e68]:
            - /url: /lumen-3-pro#buy
            - text: Buy ›
      - generic [ref=e72]:
        - paragraph [ref=e73]: Lumen 3
        - paragraph [ref=e74]: Everything you need. Nothing you don't.
        - paragraph [ref=e75]:
          - link "Learn more" [ref=e76]:
            - /url: /lumen-3-pro
            - text: Learn more ›
          - link "Buy" [ref=e77]:
            - /url: /lumen-3-pro#buy
            - text: Buy ›
      - generic [ref=e81]:
        - paragraph [ref=e82]: Lumen Watch
        - paragraph [ref=e83]: A day, measured properly.
        - paragraph [ref=e84]:
          - link "Learn more" [ref=e85]:
            - /url: /lumen-3-pro
            - text: Learn more ›
      - generic [ref=e89]:
        - paragraph [ref=e90]: Lumen Buds
        - paragraph [ref=e91]: Quiet, on demand.
        - paragraph [ref=e92]:
          - link "Learn more" [ref=e93]:
            - /url: /lumen-3-pro
            - text: Learn more ›
      - link "Trade in Get up to £600 toward a new Lumen." [ref=e95]:
        - /url: /lumen-3-pro#trade
        - generic [ref=e97]:
          - paragraph [ref=e98]: Trade in
          - paragraph [ref=e99]: Get up to £600 toward a new Lumen.
    - generic [ref=e100]:
      - generic [ref=e102]:
        - heading "Why buy from Lumen" [level=2] [ref=e104]
        - link "Shop all" [ref=e105]:
          - /url: /lumen-3-pro
          - text: Shop all ›
      - generic [ref=e106]:
        - group "Why buy from Lumen" [ref=e107]:
          - article [ref=e108]:
            - link "Trade in Turn the one in your pocket into credit. An estimate takes two minutes, and the value comes off at checkout." [ref=e109]:
              - /url: /lumen-3-pro#trade
              - generic [ref=e110]:
                - paragraph [ref=e111]: Trade in
                - paragraph [ref=e112]: Turn the one in your pocket into credit.
                - paragraph [ref=e113]: An estimate takes two minutes, and the value comes off at checkout.
          - article [ref=e116]:
            - link "Carriers Every network, no upsell. Bring the number you have, on the plan you already pay for." [ref=e117]:
              - /url: /lumen-3-pro#buy
              - generic [ref=e118]:
                - paragraph [ref=e119]: Carriers
                - paragraph [ref=e120]: Every network, no upsell.
                - paragraph [ref=e121]: Bring the number you have, on the plan you already pay for.
          - article [ref=e124]:
            - link "Pay monthly Spread it over 24 months, interest free. No deposit, no fee, and settle early whenever you like." [ref=e125]:
              - /url: /lumen-3-pro#buy
              - generic [ref=e126]:
                - paragraph [ref=e127]: Pay monthly
                - paragraph [ref=e128]: Spread it over 24 months, interest free.
                - paragraph [ref=e129]: No deposit, no fee, and settle early whenever you like.
          - article [ref=e132]:
            - link "Setup Everything moves across in one go. Photos, messages, apps, and the way you had them arranged." [ref=e133]:
              - /url: /guide/quickstart
              - generic [ref=e134]:
                - paragraph [ref=e135]: Setup
                - paragraph [ref=e136]: Everything moves across in one go.
                - paragraph [ref=e137]: Photos, messages, apps, and the way you had them arranged.
          - article [ref=e140]:
            - link "Support A person, not a phone tree. Free for two years, by chat or in person, whichever suits." [ref=e141]:
              - /url: /guide
              - generic [ref=e142]:
                - paragraph [ref=e143]: Support
                - paragraph [ref=e144]: A person, not a phone tree.
                - paragraph [ref=e145]: Free for two years, by chat or in person, whichever suits.
        - generic [ref=e148]:
          - button "Scroll left" [disabled] [ref=e149]
          - button "Scroll right" [ref=e152] [cursor=pointer]
  - contentinfo [ref=e155]:
    - generic [ref=e156]:
      - generic [ref=e157]:
        - text: Lumen
        - paragraph [ref=e158]: Light, captured.
      - navigation "Footer" [ref=e159]:
        - generic [ref=e160]:
          - heading "Shop" [level=2] [ref=e161]
          - list [ref=e162]:
            - listitem [ref=e163]:
              - link "Lumen 3 Pro" [ref=e164]:
                - /url: /lumen-3-pro
            - listitem [ref=e165]:
              - link "Trade in" [ref=e166]:
                - /url: /lumen-3-pro#trade
        - generic [ref=e167]:
          - heading "Learn" [level=2] [ref=e168]
          - list [ref=e169]:
            - listitem [ref=e170]:
              - link "Guide" [ref=e171]:
                - /url: /guide
            - listitem [ref=e172]:
              - link "Specifications" [ref=e173]:
                - /url: /lumen-3-pro#specs
        - generic [ref=e174]:
          - heading "Support" [level=2] [ref=e175]
          - list [ref=e176]:
            - listitem [ref=e177]:
              - link "Getting started" [ref=e178]:
                - /url: /guide/quickstart
    - generic [ref=e179]:
      - paragraph [ref=e180]: © 2026 Lumen — a fictional brand, built to exercise Zellij.
      - list [ref=e181]:
        - listitem [ref=e182]:
          - link "Github" [ref=e183]:
            - /url: https://github.com/shebka/zellij
  - alert [ref=e184]
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { writeFile } from 'node:fs/promises';
  3  | import { browserFailureState } from '../../../scripts/browser-failure-state.mjs';
  4  | const variants = [
  5  |   { name: 'showcase-control', url: '/' },
  6  |   { name: 'escape-cancel', url: '/' },
  7  |   { name: 'showcase-flat', url: '/' },
  8  |   { name: 'dom-effects', url: '/__resize-reduction/dom.html' },
  9  |   { name: 'dom-flat', url: '/__resize-reduction/dom.html?effects=off' },
  10 | ].filter(variant => variant.name === (process.env.PROBE_VARIANT ?? 'showcase-control'));
  11 | const observedErrors = new WeakMap<Page, string[]>();
  12 | test.afterEach(async ({ page }, info) => {
  13 |   if (info.status === info.expectedStatus) return;
  14 |   const output = info.outputPath('resize-state.json');
  15 |   await writeFile(output, JSON.stringify({ status: info.status, title: info.title,
  16 |     worker: info.parallelIndex, capturedAtEpochMs: Date.now(), pageErrors: observedErrors.get(page) ?? [],
  17 |     state: await browserFailureState(page) }, null, 2));
  18 |   await info.attach('resize-state', { path: output, contentType: 'application/json' });
  19 | });
  20 | 
  21 | // Distinct cases share the normal two worker/browser processes. No repeat-each
  22 | // worker restart, active heartbeat or injected stall; assertion deadlines stay 5s.
  23 | for (let iteration = 0; iteration < 64; iteration++) {
  24 |   for (const variant of variants) {
  25 |     test(`${variant.name} / sequence ${iteration + 1}`, async ({ page }, info) => {
  26 |       const errors: string[] = [];
  27 |       observedErrors.set(page, errors);
  28 |       page.on('pageerror', error => errors.push(error.message));
  29 |       if (variant.name === 'escape-cancel') await page.addInitScript(() => {
  30 |         document.addEventListener('keydown', event => {
  31 |           if (event.key === 'Escape') event.preventDefault();
  32 |         }, true);
  33 |       });
  34 |       await page.goto(variant.url, { waitUntil: 'networkidle' });
  35 |       await page.evaluate(() => document.fonts.ready);
  36 |       const nav = page.getByRole('navigation', { name: 'Main', exact: true });
  37 |       if (variant.url === '/') {
  38 |         await page.addStyleTag({ content: '.zellij-nav-link, .zellij-nav-probe-label { font-size: 1.25rem; }' });
  39 |       }
  40 |       if (variant.name === 'showcase-flat') await page.addStyleTag({ content:
  41 |         '*, *::before, *::after { animation: none !important; transition: none !important; filter: none !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }',
  42 |       });
  43 |       for (let cycle = 0; cycle < 5; cycle++) {
  44 |         await test.step(`narrow/open/Escape/widen ${cycle + 1}`, async () => {
  45 |           await page.setViewportSize({ width: 901, height: 900 });
  46 |           const more = nav.locator('[data-nav-index="more"] > button');
  47 |           await expect(more).toBeVisible();
  48 |           await expect(nav.locator('[data-nav-index]:not([data-nav-index="more"])')).toHaveCount(0);
  49 |           await more.focus();
  50 |           await page.keyboard.press('ArrowDown');
  51 |           await expect(nav.locator('[data-nav-index="more"] a').first()).toBeFocused();
  52 |           await expect(nav.locator('[data-nav-index="more"] a').filter({ hasText: 'Guide' }).last()).toBeVisible();
  53 |           await page.keyboard.press('Escape');
  54 |           await expect(more).toBeFocused();
  55 |           // Keep the critical Escape → resize interval free of extra evaluation.
  56 |           await page.setViewportSize({ width: 1600, height: 900 });
> 57 |           await expect(more).toHaveCount(0);
     |                              ^ Error: expect(locator).toHaveCount(expected) failed
  58 |           await expect(nav.getByRole('link', { name: 'Guide', exact: true })).toBeVisible();
  59 |           await expect(nav.locator('[data-zellij-navitem]:focus')).toHaveCount(1);
  60 |         });
  61 |       }
  62 |       await info.attach('page-errors', { body: JSON.stringify(errors), contentType: 'application/json' });
  63 |       expect(errors).toEqual([]);
  64 |     });
  65 |   }
  66 | }
  67 | 
```